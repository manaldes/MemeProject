//
//  ViewController.swift
//  memeV1
//
//  Created by Manal  harbi on 30/01/1441 AH.
//  Copyright © 1441 Udasity. All rights reserved.
//

import UIKit

class MemeEditorVC: UIViewController ,UITextFieldDelegate,  UIImagePickerControllerDelegate , UINavigationControllerDelegate{

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var AlbumButton: UIBarButtonItem!
    @IBOutlet weak var textBottom: UITextField!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var textTop: UITextField!
    
    @IBOutlet weak var navBar: UIToolbar!
    
    @IBOutlet weak var toolBar: UIToolbar!
    
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
       
        setupTextField(tf: textTop, text: "TOP")
        setupTextField(tf: textBottom, text: "BOTTOM")
        
        shareButton.isEnabled = false
        title = "Create"
    
    }


func setupTextField(tf: UITextField, text: String) {
    let tfTextAttributes : [NSAttributedString.Key: Any]  = [
        NSAttributedString.Key(rawValue: NSAttributedString.Key.foregroundColor.rawValue) : UIColor.white,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeColor.rawValue) : UIColor.black,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue) : UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeWidth.rawValue): -4.0,
    ]
    
    tf.defaultTextAttributes = tfTextAttributes
    tf.textColor = UIColor.white
    tf.tintColor = UIColor.white
    tf.textAlignment = .center
    tf.text = text
    tf.delegate = self
}
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
    }
    
    func textFieldDidBeginEditing( _ textField: UITextField) {
    if ( textField.tag == 2 )
    {
        textTop.text = ""
    }else {
        textBottom.text = ""
        }
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(keyboardWillHide(_:)),
                                               name: UIResponder.keyboardWillHideNotification,
                                               object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self,
                                                  name: UIResponder.keyboardWillHideNotification,
                                                  object: nil)
        
    }
    
    
    @objc func keyboardWillShow(_ notification:Notification) {
        
        view.frame.origin.y -= getKeyboardHeight(notification)
    }
    
    @objc func keyboardWillHide(_ notification:Notification) {
       
        if textBottom.isFirstResponder {
            view.frame.origin.y -= getKeyboardHeight(notification)
        }
        
        view.frame.origin.y = 0
    }
    
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
  
    
    func textFieldShouldReturn (_ textField: UITextField) -> Bool {
    
        if textTop.isFirstResponder {
            textBottom.becomeFirstResponder()
        } else {
            view.endEditing(true)
        }
        return true
    }
   
    
    
    
    
    @IBAction func pickAnImageFromAlbum(_ sender: Any) {
        
      chooseImageFromCameraOrPhoto (source: .photoLibrary)
    }
    
    
    
    @IBAction func pickAnImageFromCamera(_ sender: Any) {
        
        chooseImageFromCameraOrPhoto (source: .camera)
    }
    
    
    func chooseImageFromCameraOrPhoto(source: UIImagePickerController.SourceType) {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.allowsEditing = true
        pickerController.sourceType = source
        present(pickerController, animated: true, completion: nil)
    }
    
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
   
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[.originalImage] as? UIImage {
            imageView.image = image
            shareButton.isEnabled = true
        }
        
        picker.dismiss(animated: true)

    }
    
    
    func generateMemedImage() -> UIImage {
        
       navBar.isHidden = true
       toolBar.isHidden = true
        
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        self.tabBarController?.tabBar.isHidden = false
        self.navigationController?.navigationBar.isHidden = false
        
        return memedImage
    }
    
    
    func save() {
        // Create the meme
       let meme = Meme(toptext: textTop.text!, bottomText: textBottom.text!, originalImage: imageView.image!, memedImage: generateMemedImage())
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.meme.append(meme)
        dismiss(animated: true, completion: nil)
    
    
    }
    
    
    @IBAction func cancelButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
    }
    @IBAction func share(_ sender: Any) {
        
        let avtivityVc = UIActivityViewController(activityItems:[generateMemedImage()] , applicationActivities: nil)
        avtivityVc.completionWithItemsHandler = {(_ , success , _, _ ) in
            if (success) {
                self.save()
            }
        }
        self.present(avtivityVc, animated: true , completion: nil)
        
   
    }
}

