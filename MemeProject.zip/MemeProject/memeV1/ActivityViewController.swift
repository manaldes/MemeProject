//
//  ActivityViewController.swift
//  memeV1
//
//  Created by Manal  harbi on 04/02/1441 AH.
//  Copyright © 1441 Udasity. All rights reserved.
//

/*import Foundation
import UIKit

class ActivityViewController : UIViewController {
    
    var completionWithItemsHandler
}
