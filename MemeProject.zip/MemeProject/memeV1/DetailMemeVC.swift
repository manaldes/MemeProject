//
//  DtailMemesVC.swift
//  memeV1
//
//  Created by Manal  harbi on 20/02/1441 AH.
//  Copyright © 1441 Udasity. All rights reserved.
//


import UIKit

class DtailMemesVC : UIViewController {
    
   
    var meme : Meme!
   
    @IBOutlet weak var imageV: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //self.imageV!.image = UIImage(named: meme?.memedImage)
        imageV.image = meme.memedImage
    }

}
