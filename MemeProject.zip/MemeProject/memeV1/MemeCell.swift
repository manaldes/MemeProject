//
//  MemeCell.swift
//  memeV1
//
//  Created by Manal  harbi on 07/02/1441 AH.
//  Copyright © 1441 Udasity. All rights reserved.
//

import Foundation
import UIKit

class MemeCell: UICollectionViewCell {
    
    @IBOutlet weak var memeimageView: UIImageView!

}
