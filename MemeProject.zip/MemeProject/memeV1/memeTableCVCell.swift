//
//  memeTableCVCell.swift
//  memeV1
//
//  Created by Manal  harbi on 17/02/1441 AH.
//  Copyright © 1441 Udasity. All rights reserved.
//

import Foundation

import UIKit

class MemetableVCCell: UITableViewCell {
    
 
    @IBOutlet weak var memeimageView: UIImageView!
    @IBOutlet weak var memedLabel: UILabel!
    
}
