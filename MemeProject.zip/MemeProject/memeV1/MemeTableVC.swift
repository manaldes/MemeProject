//
//  MemeTableVC.swift
//  memeV1
//
//  Created by Manal  harbi on 14/02/1441 AH.
//  Copyright © 1441 Udasity. All rights reserved.
//

import Foundation
import UIKit

class MemetableVC: UITableViewController {
    
    
    
    var memes : [Meme] {
      return (UIApplication.shared.delegate as! AppDelegate).meme
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self

    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if memes.count == 0 {
            tableView.separatorStyle = .none
            tableView.backgroundView?.isHidden = false
        } else {
            tableView.separatorStyle = .singleLine
            tableView.backgroundView?.isHidden = true
        }
        return memes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellTV") as! MemetableVCCell
        
        let Meme = memes[indexPath.row]
        cell.memeimageView?.image = memes[indexPath.row].memedImage
        cell.memedLabel?.text = "\(Meme.toptext)... \(Meme.bottomText)..."
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DtailMemesVC") as! DtailMemesVC
        //detailVC.meme = self.memes[(indexPath as NSIndexPath ).row]
        detailVC.meme = memes[indexPath.row]
        navigationController?.pushViewController( detailVC, animated: true)
    }
}
