//
//  DtailMemesVC.swift
//  memeV1
//
//  Created by Manal  harbi on 14/02/1441 AH.
//  Copyright © 1441 Udasity. All rights reserved.
//

import Foundation
import UIKit

class DtailMemesVC : UIViewController {
    
    var meme : Meme
    
    @IBOutlet weak var imageV: UIImageView!
    
/*   init(meme : Meme) {
        self.meme = meme
        super.init(nibName: nil, bundle: nil)
        view.backgroundColor = .white
        let image = UIImageView ()

        view.addSubview(image)
        image.translatesAutoresizingMaskIntoConstraints = false
        image.image = meme.memedImage
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
*/
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        imageV.image = meme.memedImage
    }
  
    
}
